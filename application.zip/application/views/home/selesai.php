<link rel="stylesheet" href="<?php  echo base_url('assets/css/styleabout.css')?>">
<div id="container">

<!--Begin About Section-->
    <div id="about">
        <h1 style="color: white">Terimakasih Pesanan anda sedang di proses</h1>
        <div class="top-divider"></div>
        <div class="content">
           
       		</div>
        </div>
    	</div>
<!--End About Section-->

	</div>
</body>
</section>