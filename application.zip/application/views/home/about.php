
<link rel="stylesheet" href="<?php  echo base_url('assets/css/styleabout.css')?>">
<div id="container">

<!--Begin About Section-->
    <div id="about">
        <h1>About Us</h1>
        <div class="top-divider"></div>
        <div class="content text-justify text-light">
            <h6>Hello Coffe merupakan situs Toko Kopi Online pertama di Bandung.</h6>
            <h6> Website ini dibangun oleh 5 Mahasiswa yang sedang menempuh pendidikan di Telkom Univesity jurusan S1 Informatika. Untuk menjawab banyaknya peminat Kopi di Bandung, maka dari itu kami membangun website ini untuk mempermudah masyarakat terutama mahasiswa di bandung untuk membeli kopi tanpa antri kembali ataupun bisa melalui delivery. Seiring berkembangnya teknologi, semakin banyak aktivitas yang dilakukan secara digital, lebih mudah dan praktis, termasuk kegiatan jual beli yang kini semakin marak dilakukan secara digital, baik melalui komputer, laptop, hingga smartphone yang bisa diakses kapan saja dan di mana saja. Hello Coffee hadir sebagai toko kopi online terpercaya dengan sistem konsumen ke konsumen. Hal ini memungkinkan setiap orang untuk menjual dan juga membeli kopi dengan mudah secara online. Sarana jual beli online Hello Cofee memiliki tujuan untuk menjadi Coffee Shop nomor satu di Indonesia. Setiap orang di Indonesia dapat memasarkan produk unggulannya di Hello Coffee dengan membuka toko online murah dengan pilihan sistem belanja satuan atau banyak. </h6> 
       		</div>
        </div>
    	</div>
<!--End About Section-->

	</div>
</body>
</section>